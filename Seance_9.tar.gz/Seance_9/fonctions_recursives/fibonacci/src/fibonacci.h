long fibonacci_recursif(int n);
long fibonacci_iteratif(int n);

void init_dynamique(int n);
void end_dynamique();
long fibonacci_dynamique(int n);
