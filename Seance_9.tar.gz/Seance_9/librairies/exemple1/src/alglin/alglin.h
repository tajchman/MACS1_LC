#include "vecteur.h"
#include "matrice.h"

void prodMatVec(Vecteur *Y, Matrice *A, Vecteur *X);
