struct toto;

int main()
{
  struct toto *T;

  return 0;
}