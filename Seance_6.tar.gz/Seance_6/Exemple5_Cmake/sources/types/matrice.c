#include "matrice.h"
#include <stdlib.h>

void alloueMatrice(Matrice *M, int n, int m)
{
}

void libereMatrice(Matrice *M)
{
}
