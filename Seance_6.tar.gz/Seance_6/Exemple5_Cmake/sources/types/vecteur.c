#include "vecteur.h"
#include <stdlib.h>

void alloueVecteur(Vecteur *v, size_t n)
{
}

void libereVecteur(Vecteur *v)
{
}
