#include <stdio.h>

int main()
{
	printf("Bonjour\n");
	return 0;
}

