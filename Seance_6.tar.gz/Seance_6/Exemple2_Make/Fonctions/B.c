#include <stdio.h>

void g(double y)
{
  printf("g : y = %g\n", y);
}