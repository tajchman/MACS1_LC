void f(double x);
