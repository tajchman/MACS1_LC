#include <stdio.h>
#include "A.h"

void f(double x)
{
  printf("f : x = %12.4g\n", x);
}
