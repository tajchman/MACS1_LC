#include "A.h"
#include "B.h"

int main()
{
  f(1);
  g(3.4);
  return 0;
}
