extern double m;
