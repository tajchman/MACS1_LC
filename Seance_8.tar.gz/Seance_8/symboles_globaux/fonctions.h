double f(double x);
