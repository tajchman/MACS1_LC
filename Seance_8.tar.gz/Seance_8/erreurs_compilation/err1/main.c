#include <stdio.h>
#include "string.h"

double f(int n)
{
  double resultat;
  printf("f: n = %s\n", n)
  resultat = n*2.0;
}

double main()
{
  int n = 10;
  printf("n = %d\n", f(n, x0));
  return 3.5;
}

